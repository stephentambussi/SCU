int x[10];

int bar();
int bar();

int foo(int a, char *b)
{
    int c[10];
}

int *x[10];			/* conflicting types for 'x' */
