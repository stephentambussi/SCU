char a, b;

int foo(int a, int b)
{
    int x, x;			/* redeclaration of 'x' */
}

char a, b;

int bar(char *b, char *b)	/* redeclaration of 'b' */
{
    int x;
    int *y, y;			/* redeclaration of 'y' */
}
