# ifndef GENERATOR_H
# define GENERATOR_H

# include "Scope.h"

void generateGlobals(Scope *global);

# endif /* GENERATOR_H */