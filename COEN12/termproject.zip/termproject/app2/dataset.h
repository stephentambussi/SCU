//header file -- app2
typedef struct set DS;
typedef struct data Data;
void createDataSet(int maxStudents);
int destroyDataSet();
int searchID(int ID);
DS insertion(int ID);
int deletion(int ID);

