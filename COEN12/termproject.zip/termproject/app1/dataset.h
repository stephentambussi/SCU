//header file -- app1
typedef struct set DS;
void createDataSet(int maxStudents);
int destroyDataSet();
void searchAge(int age);
DS insertion(int age);
int deletion(int age);
int maxAgeGap();


